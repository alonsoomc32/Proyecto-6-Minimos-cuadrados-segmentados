package grafo;


import java.awt.Color;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DiBot
 */
public class G extends JFrame {  									
	ArrayList<Point2D> pointList = new ArrayList<>();
	ArrayList<Point2D> lineList = new ArrayList<>();
	
	public G() { 											
		initUI();
	}
	public G(ArrayList<Point2D> pL, ArrayList<Point2D> lL) {
		pointList = pL;
		lineList = lL;
		initUI();
	}
	private void initUI(){										
            XYDataset datos = generadatos();    				
            JFreeChart chart = ChartFactory.createScatterPlot( "Minimos cuadrados segmentados","X","Y",datos,PlotOrientation.HORIZONTAL,true,true,false );
		
	    chart.setBackgroundPaint(Color.white);
            XYPlot plot = chart.getXYPlot();
            plot.setBackgroundPaint(Color.white);
            plot.setRangeGridlinesVisible(true);
	    plot.setRangeGridlinePaint(Color.BLACK);
	    plot.setDomainGridlinesVisible(true);
	    plot.setDomainGridlinePaint(Color.BLACK);
	    XYLineAndShapeRenderer lsRenderer = new XYLineAndShapeRenderer();
	    lsRenderer.setSeriesLinesVisible(0, false);
	    lsRenderer.setSeriesShapesVisible(1, false);
            plot.setRenderer(lsRenderer);
           final NumberAxis range = (NumberAxis) plot.getRangeAxis();
           range.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		
        ChartPanel panel = new ChartPanel(chart);		
		setContentPane(panel);  
	}
	private XYDataset generadatos() {
		
		XYSeriesCollection datos = new XYSeriesCollection();
		
		XYSeries series1 = new XYSeries("Puntos"); 	
		for(Point2D i:pointList){
			series1.add(i.getX(), i.getY());
	    }
		datos.addSeries(series1);
		
		XYSeries series2 =new XYSeries("");			
		datos.addSeries(series2);
		
		XYSeries series3 = new XYSeries("Linea"); 	
		for(Point2D i:lineList){
        	series3.add(i.getX(), i.getY());
        }
		datos.addSeries(series3);

	    return datos;
	}  
}

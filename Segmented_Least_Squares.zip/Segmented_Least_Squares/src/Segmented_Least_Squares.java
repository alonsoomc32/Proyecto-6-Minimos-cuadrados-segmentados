
import grafo.G;
import java.awt.geom.Point2D;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Segmented_Least_Squares {	
        //VARIABLES
    
	private static ArrayList<Point2D> pointList = new ArrayList<>();
	private static ArrayList<Point2D> lineXY 	= new ArrayList<>();
	private static int C; 							
	private static int N; 							
	private static double [] lookupOPT;						
	private static int [] INDEX;							
	private static double [][] Eij;							
	private static double [][][] ABlist;						
	private static double BOUND = Double.POSITIVE_INFINITY;		
	private static double result;
	
        //GENERO PUNTOS ALEATORIOS
	private static void generador() throws FileNotFoundException{

   	    for(int i =0; i <=10; i++)
		{ 	
   	    	double valorAleatorio = Math.random()*(10-0);   	    	
   	    	double valorAleatorio2 = Math.random()*(10-0);  
   	    	double x; double y;
			x = Double.valueOf(valorAleatorio);
			y = Double.valueOf(valorAleatorio2);
			Point2D.Double pointDouble = new Point2D.Double(x, y);
		    pointList.add(pointDouble);
		}

		
	N = pointList.size();
	lookupOPT = new double[N + 1];
	INDEX= new int[N + 1];
        Eij= new double[N + 1][N + 1];
        ABlist= new double[2][N + 1][N + 1]; 
	}
            //VALORES DE ENTRADA
	private static void entrada(){ 				
		Scanner reader = new Scanner(System.in);
		System.out.print("Dame un entero: ");
		C = reader.nextInt();
		reader.close();
		System.out.println("Coeficiente: "+C);
	}
	//CALCULOS
	private static void optimo(){
		error();
		lookupOPT[0] = 0;
		for(int j = 1; j <= N; j++){ double min = BOUND;
			int inx = 0;
			for(int i = 1; i <= j; i++){
				double tmp = Eij[i][j] + lookupOPT[i-1] + C;
				if(tmp < min){min = tmp;inx = i;}
			}
			lookupOPT[j] = min;
			INDEX [j] = inx;
		}
		result = lookupOPT[N];
	}
	
	private static void error(){				
		for(int j = 1; j <= N; j++){
			for(int i = 1; i <= j; i++){
				if(i == j) 	{ Eij[i][j] = BOUND; }
				else		{ Eij[i][j] = dameDistancia(i,j); }
			}
		}
	}
	
	private static double dameDistancia(int i, int j){ 	
		double 	 val= 0;
		int 	 n = j - i + 1;
		double 	 a= 0;
		double 	 b = 0;
		double 	 sumatoriap= 0;
		double 	 sumaX 	= 0;
		double 	 sumAY 	= 0;
		double 	 sumaX2	= 0;
		
		for(int k = i; k < j; k++){ 				
			double X = pointList.get(k).getX();
			double Y = pointList.get(k).getY();
			sumatoriap += X * Y; 
			sumaX += X; 
			sumAY += Y;
			sumaX2+= X * X;
		}
		
		double num = ((n * sumatoriap) - (sumaX * sumAY));
		if(num != 0)
		{
			double denum = ((n * sumaX2) - (sumaX * sumaX));
			if(denum != 0){ a = num / denum;} 		
		}
		b = (sumAY-(a*sumaX))/n;
		
		ABlist[0][i][j] = a;
		ABlist[1][i][j] = b;
		
		for(int k = i; k <= j; k++){ 				
			double X = pointList.get(k-1).getX();
			double Y = pointList.get(k-1).getY();
			double tmp = Y - a * X - b;
			val += tmp * tmp;
		}
		
		return val;
	}
	
	private static void dameIndex(){				
            Stack<Integer> stack = new Stack<Integer>();
        for(int terminaIndex = N, iniciaIndex = INDEX[N]; terminaIndex > 0; terminaIndex = iniciaIndex - 1, iniciaIndex = INDEX[terminaIndex]) {
            stack.push(terminaIndex);
            stack.push(iniciaIndex);
        }
        imprime(stack);
    }

    private static void imprime(Stack<Integer> stack){
        System.out.println("Costo: " + result);
        System.out.println("Lineas:");
        int k = 1;
        while(!stack.isEmpty()){
        	int i = stack.peek(); stack.pop();			
    		int j = stack.peek(); stack.pop();			
    		System.out.println("Inicio "+k+": " + i + " Fin : " +j + " ---> x: "+ ABlist[0][i][j]+" y: "+ ABlist[1][i][j]);
    		k++; linea(i,j);					
        }
    }
    
    private static void linea(int i, int j){ 	
    		double a = ABlist[0][i][j];
    		double b = ABlist[1][i][j];
    		double X = pointList.get(i-1).getX();
    		double Y = a * X + b;
    		lineXY.add(new Point2D.Double(X,Y));	
    		X = pointList.get(j-1).getX();
    		Y = a * X + b;
    		lineXY.add(new Point2D.Double(X,Y)); 	
    }
    
    private static void dibuja(){ 				
		SwingUtilities.invokeLater(() -> {
		G grafo = new G(pointList,lineXY);
		grafo.pack();
		grafo.setSize(1200, 600);
		grafo.setLocationRelativeTo(null);
		grafo.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		grafo.setVisible(true);
        });	
	}
    
	public static void main(String[] args) throws FileNotFoundException {
		generador();
		entrada();
		optimo();
		dameIndex();
		dibuja();	
	}
}



